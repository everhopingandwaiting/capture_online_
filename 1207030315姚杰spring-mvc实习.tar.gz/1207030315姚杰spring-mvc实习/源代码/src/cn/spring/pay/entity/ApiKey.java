package cn.spring.pay.entity;

/**
 * Created by john on 15-12-13.
 */
public class ApiKey {
    public static String APIKEY = "sk_test_P4KGSGrf1Ou1qX54mDbfzLG0";
    public static String APPID = "app_OuzfnLX9y9e5rjzX";
}
