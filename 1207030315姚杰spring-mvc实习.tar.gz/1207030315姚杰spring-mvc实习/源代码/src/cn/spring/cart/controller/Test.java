package cn.spring.cart.controller;

import java.util.Date;

/**
 * Created by john on 15-11-26.
 */
public class Test {
    public static void main(String[] args) {
        System.out.println("\u535a\u5ba2");

        Date date = new Date();
        System.out.println(date);

    }
}
