package cn.spring.guest.form;

/**
 * Created by john on 15-11-25.
 */
public  class cck {
    public static void main(String[] args) {
        System.out.println("\084");
    }
}

