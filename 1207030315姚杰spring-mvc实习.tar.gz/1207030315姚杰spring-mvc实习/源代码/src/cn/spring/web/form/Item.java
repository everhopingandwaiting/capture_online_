package cn.spring.web.form;

import lombok.Data;

@Data
public class Item {

	private String label;
	private String value;
}
