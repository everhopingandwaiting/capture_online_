package cn.spring.web.form;


import lombok.Data;

@Data
public class UVO {
	private int userId;
    private String name;
    private String password;
    private String role;

}
