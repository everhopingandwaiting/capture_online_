package com.pingplusplus.model;

public class TransferCollection extends PingppCollection<Transfer> {
}
