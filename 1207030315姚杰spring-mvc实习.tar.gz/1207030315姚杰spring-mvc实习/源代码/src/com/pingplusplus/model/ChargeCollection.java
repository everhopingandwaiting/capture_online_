package com.pingplusplus.model;

public class ChargeCollection extends PingppCollection<Charge> {
}
