package com.pingplusplus.model;

public class CustomerCollection extends PingppCollection<Customer> {
}
