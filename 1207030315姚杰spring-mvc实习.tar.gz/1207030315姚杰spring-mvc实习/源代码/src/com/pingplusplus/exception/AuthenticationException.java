package com.pingplusplus.exception;

public class AuthenticationException extends PingppException {


	public AuthenticationException(String message) {
		super(message);
	}

	private static final long serialVersionUID = 1L;

}
